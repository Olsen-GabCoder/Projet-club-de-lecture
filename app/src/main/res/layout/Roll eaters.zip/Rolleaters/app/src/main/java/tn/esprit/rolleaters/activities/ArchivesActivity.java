package tn.esprit.rolleaters.activities;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class ArchivesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}